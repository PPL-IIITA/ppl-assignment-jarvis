# ppl-assignment-jarvis004 
ppl-assignment-The-Master-Coder created by GitHub Classroom <br />
#Mritunjay Chaudhary (**BIM2015004**)

##Build System:
>Kali GNU 2016.2 <br />
>OS type 32bit

##Command for Terminal in Linux:
Note: All the codes submitted are tested on  only openjdk version "1.8.0_121"
>javac q1.java    (in folder q1, for Question 1)<br />


