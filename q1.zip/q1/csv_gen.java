import java.io.*;
import java.util.*;
public class csv_gen {
	    void csv(){
		try{
			FileWriter boy_file = new FileWriter("boys.csv");
			FileWriter girl_file = new FileWriter("girls.csv");
			int j;
			Random boy_rand = new Random();
			Random girl_rand = new Random();
			for(j=0;j<=20;j++){
				boy_file.write("B"+j+","+boy_rand.nextInt(10)+","+boy_rand.nextInt(10)+","+boy_rand.nextInt(10)+","+boy_rand.nextInt(1000)+","+"Single"+"\n");
			}
			for(j=0;j<=7;j++){
				girl_file.write("G"+j+","+girl_rand.nextInt(10)+","+girl_rand.nextInt(1000)+","+girl_rand.nextInt(10)+","+"Single"+"\n");
			}
			boy_file.close();
			girl_file.close();
		}catch(IOException e){		
		
		}
	
		
}
	    
}
